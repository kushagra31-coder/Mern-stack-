import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { visualizer } from 'rollup-plugin-visualizer'

export default defineConfig({
  plugins: [
    react(),
    visualizer({
      open: true,        // auto-opens treemap after build
      filename: 'dist/bundle-report.html',
      gzipSize: true,
      brotliSize: true,
    })
  ],
})